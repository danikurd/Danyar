<?php


//KONTROL UNTUK DESKRIPSI HALAMAN
$title = 'PUBG MOBILE - Lucky Spin Season 13';
$description = 'Royale Pass Season 13 has begun! Collect your favorite prizes here right now !!! This promo is free without the need for topup. Come join this event with friends all over the world now!';
$copyright = 'PUBG MOBILE';
$theme = '#000';
$image = 'https://i.ibb.co/3CSfdjd/season.png';
$icon = 'img/icon.jpg';

?>
